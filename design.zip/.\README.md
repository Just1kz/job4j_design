# job4j_design
[![Build Status](https://travis-ci.org/Just1kz/job4j_design.svg?branch=master)](https://travis-ci.org/Just1kz/job4j_design)
[![codecov](https://codecov.io/gh/Just1kz/job4j_design/branch/master/graph/badge.svg?token=1ZTL4A4MX1)](https://codecov.io/gh/Just1kz/job4j_design)