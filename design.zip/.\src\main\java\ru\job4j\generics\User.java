package ru.job4j.generics;

public class User extends Base {
    User(String id) {
        super(id);
    }
}
